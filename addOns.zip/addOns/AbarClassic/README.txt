Currently working player swing timer for BFA. Not tested for Classic.
