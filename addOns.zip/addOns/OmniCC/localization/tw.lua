if GetLocale() ~= 'zhTW' then return end
local L = OMNICC_LOCALS

-- effect names
L.Updated = "升級至 v%s"
L.Pulse = "脈衝"
L.Shine = "閃亮"