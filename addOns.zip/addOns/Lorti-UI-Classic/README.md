# Lorti UI Classic. 

**IF ANYONE WANTS TO TAKE OVER THIS PROJECT, PM ME ON DISCORD AND I'LL TRANSFER THE PROJECT TO YOU**

Discord: Chordsy#8773

I feel pretty done with this, and will mostly just fix major issues if any pops up. 
Let me know if you have a solution to the minimap clock frame and how to colour it.

Remove the "-master" when downloaded. Folder should look like this: \Interface\AddOns\Lorti-UI-Classic
